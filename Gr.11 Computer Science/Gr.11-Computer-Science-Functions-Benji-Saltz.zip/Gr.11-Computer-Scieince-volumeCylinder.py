########################################
# Programmer:Benji Saltz
# Date: oct.17/16
# File Name: volumeCylinder.py
# Description: Template for a function
########################################

def volumeCylinder(height, radius):
    """ (float, float) -> (float)

    Return the volume of a cylinder with given height and radius of the base.

    >>> volumeCylinder(10, 2)
    125.66
    >>> volumeCylinder(5, 20)
    6283.19
    """

#

    # write your code here
    import math
    
    return round(math.pi*(radius**2)*height,2)
#
########################################
if __name__ == '__main__':
    import doctest
    doctest.testmod()


