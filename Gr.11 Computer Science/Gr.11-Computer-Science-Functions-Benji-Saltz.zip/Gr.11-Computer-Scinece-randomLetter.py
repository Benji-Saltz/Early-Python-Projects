########################################
# Programmer:Benji Saltz
# Date: oct.17/16
# File Name: randomLetter.py
# Description: Template for a function
########################################

def randomLetter():
    import random
    """ (None) -> (str)

    Return a random capital letter.

    """
#

    # write your code here
    return chr(random.randint(65,89))
#
########################################
if __name__ == '__main__':
    import doctest
    doctest.testmod()


