#Name: Benji Saltz
#Date: 17/11/16
#Description: Enter an number and outputs a month corresponding to it
'''
(int)->(str)
Returns a month from a corresponding number which is inputed

ex.1
>>> Number_to_month()
Enter a number to turn to a month: 5
May

ex.2
>>> Number_to_month()
Enter a number to turn to a month: 1
January

ex.3
>>> Number_to_month()
Enter a number to turn to a month: 13
Error
'''
def Number_to_month():
    months=['January','February','March','April','May','June','July','August','September','October','November','December']
    number=int(input("Enter a number to turn to a month: "))
    if (number>=1 and number<=12):
        print(months[number-1])
    else:
        print("Error")
        
   
